# University_CAMPUS-Networking-Project-using-Packet-Tracer
I have made a network topology of a university in which we have a main campus  and a branch campus. All the departments in the main campus can communicate  with each other and similarly in branch campus. Only admin department o main  campus can communicate with branch campus
